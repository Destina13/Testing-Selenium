package automationFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Tenth {

	public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Aplikasi\\chromedriver-win64\\chromedriver.exe");

        // Create a new instance of the Chrome Driver
        WebDriver wd = new ChromeDriver();

        // Launch the Bukalapak online store website
        wd.get("https://www.bukalapak.com/");
     	
        // Type xpath untuk membuka fitur Mulai Jualan
        wd.findElement(By.xpath("//*[@id=\"vm__white-header-dweb\"]/section/header/div[1]/div/div/div/div/span[2]/a")).click();
      
        
        // Print message to the screen
        System.out.println("Successfully opened Mulai Jualan in website Bukalapak ");

        // Wait for 5 secs
        Thread.sleep(5000);

        // Close the driver
        //wd.quit();
    }
}

