package automationFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SecondTestCase {

	public static void main(String[] args) throws InterruptedException{
		System.setProperty("webdriver.chrome.driver", "C:\\Aplikasi\\chromedriver-win64\\chromedriver.exe");
		
		//Create a new instance of the Chrome Driver
		WebDriver wd = new ChromeDriver();
		
		//Launch the Bukalapak online store website
		wd.get("https://www.bukalapak.com/");
		
		// Type xpath to click menu Login
		wd.findElement(By.xpath("//*[@id='vm__white-header-dweb']/section/header/div[3]/div/div/div[2]/div/a[2]/p")).click();

		//Type email in Email text box
		wd.findElement(By.xpath("/html/body/div[1]/main/div/div[2]/section/section[1]/div[1]/div[1]/div/div[1]/div")).sendKeys("destinamanurung8@gmail.com");
		
		//Type xpath to click button submit
		wd.findElement(By.xpath("//*[@id=\"submit_button\"]")).click();
		
		//Print message to the screen
		System.out.println("Successfully to open page login in the website Bukalapak DemoQA");
		
		//Wait for 5 secs
		Thread.sleep(50000);
		
		//Close the driver
		//wd.quit();
	}

}