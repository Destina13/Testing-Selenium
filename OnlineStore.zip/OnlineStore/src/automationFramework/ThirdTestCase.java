package automationFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ThirdTestCase {

	public static void main(String[] args) throws InterruptedException{
		System.setProperty("webdriver.chrome.driver", "C:\\Aplikasi\\chromedriver-win64\\chromedriver.exe");
		
		//Create a new instance of the Chrome Driver
		WebDriver wd = new ChromeDriver();
		
		//Launch the Bukalapak online store website
		wd.get("https://www.bukalapak.com/");
		
		// Type xpath to click menu Daftar
		wd.findElement(By.xpath("//*[@id=\"vm__white-header-dweb\"]/section/header/div[3]/div/div/div[2]/div/a[1]/p")).click();

		//Type email in Email text box
		wd.findElement(By.xpath("/html/body/main/div/div[2]/section/div[1]/div[1]/div")).sendKeys("destinamanurung8@gmail.com");
				
		//Type xpath to click button Daftar
		wd.findElement(By.xpath("//*[@id=\\\"daftar_button\\\"]")).click();
		
		//Print message to the screen
		System.out.println("Successfully to open page Reistrasi in the website Bukalapak DemoQA");
				
		//Wait for 5 secs
		Thread.sleep(50000);
		
		//Close the driver
		//wd.quit();
	}
}
