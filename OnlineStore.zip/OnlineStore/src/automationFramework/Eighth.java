package automationFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Eighth {

	public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Aplikasi\\chromedriver-win64\\chromedriver.exe");

        // Create a new instance of the Chrome Driver
        WebDriver wd = new ChromeDriver();

        // Launch the Bukalapak online store website
        wd.get("https://www.bukalapak.com/");
     	
        // Type xpath untuk membuka sosial media Bukalapak yaitu YouTube
        wd.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div[2]/ul/li[3]/a")).click();
      
        // Print message to the screen
        System.out.println("Successfully opened youtube Bukalapak ");

        // Wait for 5 secs
        Thread.sleep(5000);

        // Close the driver
        //wd.quit();
    }
}


