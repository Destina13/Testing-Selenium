package automationFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Seventh {

	public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Aplikasi\\chromedriver-win64\\chromedriver.exe");

        // Create a new instance of the Chrome Driver
        WebDriver wd = new ChromeDriver();

        // Launch the Bukalapak online store website
        wd.get("https://www.bukalapak.com/");
     	
        // Type xpath untuk menambahkan pertanyaan
        wd.findElement(By.xpath("/html/body/div[3]/div[2]/div/div/div[1]/p[2]/a")).click();
      
        // Print message to the screen
        System.out.println("Successfully opened FAQ(Tanya Jawab) in the website Bukalapak DemoQA");

        // Wait for 5 secs
        Thread.sleep(5000);

        // Close the driver
        //wd.quit();
    }
}
